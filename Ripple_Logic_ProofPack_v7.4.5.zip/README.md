# Ripple_Logic ProofPack v7.4.5

This ProofPack is a *canon-binding* bundle for replayability and audit discipline.

## Contents
- `canon/` — canonical Foundation Paper (DOCX + extracted TXT)
- `schemas/` — JSON schemas for PCC + registry snapshots
- `templates/` — PCC templates (Markdown + JSON)
- `test_vectors/` — skeleton inputs for Tier-1 and Tier-3 runs
- `hashes.sha256` — SHA-256 hashes for every file in the ProofPack
- `registry_snapshot.json` — machine-readable index of artifact hashes
- `manifest.json` — top-level entrypoint

## Verification
Compute SHA-256 for all files and compare to `hashes.sha256`.

## SGP Dependency
If a run relies on SGP v4.1.1 outputs, include the SGP artifact inside this ProofPack OR pin it by hash and registry ID per Appendix G of the canon.

