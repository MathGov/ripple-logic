#!/usr/bin/env python3
import hashlib, os, sys

def sha256_file(path:str)->str:
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

root=sys.argv[1] if len(sys.argv)>1 else "."
rows=[]
for dirpath,_,filenames in os.walk(root):
    for fn in filenames:
        if fn in ["hashes.sha256"]: 
            continue
        p=os.path.join(dirpath,fn)
        rel=os.path.relpath(p, root).replace("\\","/")
        rows.append((rel, sha256_file(p)))
for rel,hh in sorted(rows):
    print(f"{hh}  {rel}")
