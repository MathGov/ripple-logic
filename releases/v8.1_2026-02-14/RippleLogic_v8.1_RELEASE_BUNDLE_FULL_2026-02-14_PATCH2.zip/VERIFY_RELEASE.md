# RippleLogic v8.1 Release Bundle (FULL) — Verification

## Contents
This bundle includes:
- Core canon: Ripple_Logic v8.1, SGP v4.2.3, RL_Agent v8.1 (DOCX)
- Tooling: Ripple Aligners Sheet v1.8.0 (XLSX)
- Packaging scaffold: ProofPack skeleton v8.1 (ZIP)
- Tier-2 EvalSuite v0.1 (ZIP)
- Release-level checksum list: SHA256SUMS_RippleLogic_v8.1_release_2026-02-14_PATCH2.txt

## Verify SHA-256
Compare locally computed hashes to the checksum file:

macOS/Linux:
  shasum -a 256 <FILE>
  # or
  sha256sum <FILE>

Windows (PowerShell):
  Get-FileHash <FILE> -Algorithm SHA256

If any hash does not match, do not mirror/rehost/cite the artifact.
