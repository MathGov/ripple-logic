# VERIFY.md — OperatorAuth (OACE) Signature Verification

This directory provides *schemas* and *example vectors* for RippleLogic Agent operator authentication.  

## What is being verified?

An operator sends a JSON envelope `command.json` with fields:
- `v, kid, ts, nonce, cmd, args, sig`

Verification checks:
1) `command.json` validates against `schemas/operator_command_envelope.schema.json`
2) `kid` matches a JWK in `examples/jwks_example.json` (or your active `jwks.json`)
3) `sig` is a valid Ed25519 signature over the **JCS-canonicalized** JSON of the envelope **without** the `sig` field.

## Canonicalization (JCS / RFC 8785)

Use JSON Canonicalization Scheme (RFC 8785):
- UTF-8
- object keys sorted lexicographically
- no extra whitespace
- numbers serialized in canonical form
- arrays kept in order

Implementers SHOULD use a vetted JCS library for their language.

## Ed25519 verification

High-level steps:
1) Parse `command.json`
2) Extract `sig` and remove `sig` from the object (unsigned payload)
3) Canonicalize the unsigned payload using JCS
4) Verify Ed25519 signature:
   - public key = JWK `x` (base64url) for the matching `kid`
   - signature = `sig` (base64url)
   - message = canonicalized bytes

## Example vectors

The files in `examples/` are *structural examples* and use placeholders:
- `BASE64URL_PUBLIC_KEY_PLACEHOLDER`
- `BASE64URL_ED25519_SIGNATURE_PLACEHOLDER`

Replace placeholders with real keys/signatures when building an integration test.

## Replay protection

Your runtime MUST reject envelopes with:
- repeated `nonce` within the replay window
- timestamps outside the allowable clock skew window
- non-monotonic `ts` for the same `kid` (if configured)

---

## Pack-level verification

After unzipping, run from the pack root:

- `sha256sum -c hashes.sha256`

All entries should report `OK`.
