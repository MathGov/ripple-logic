# RippleLogic v9.6.4 Release Index

## Canonical artifacts
- `core/RippleLogic_v9.6.4_Canon.docx` - governing canon for this release line.
- `core/SGP_v4.7.1.docx` - Sentience Gradient Protocol companion.
- `core/ripple_md_Standard_v2.2.docx` - portable alignment contract and assurance wrapper.
- `core/RippleLogic_Agent_System_v9.2.docx` - agentic deployment and control specification.
- `core/RippleLogic_Aligners_Sheet_v2.5.xlsx` - worked-run companion workbook.

## Companion pins
- RippleLogic v9.6.4
- SGP v4.7.1
- ripple.md v2.2
- RippleLogic Agent System v9.2
- RippleLogic Aligners Sheet v2.5

## What is claimable
- Tier 1-3 framework conformance, subject to the canon and run-level artifact requirements.
- Bounded supervised Tier-2 pilot preparation using the pilot localization pack.

## What is not claimable
- Tier 4 conformance.
- Full empirical validation across domains or jurisdictions.
- Autonomous public-authority deployment readiness.
- Coercive deployment authorization.
- Legal approval for Nepal, Vietnam, New Zealand, or any jurisdiction.
- SGP-based governance authority.

## Checksums and manifests
Artifact identity is controlled by:
- `manifests/RippleLogic_bundle_v9.6.4_release_manifest.yaml`
- `manifests/RippleLogic_bundle_v9.6.4_release.sha256`
- `manifests/RippleLogic_Core_and_Pilot_Localization_combined_manifest.yaml`
- `manifests/RippleLogic_Core_and_Pilot_Localization_combined.sha256`

Pin exact filenames and hashes from the manifests when citing or implementing this release.
